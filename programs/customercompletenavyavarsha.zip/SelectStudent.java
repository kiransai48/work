
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SelectStudent")

public class SelectStudent extends HttpServlet {

       
   
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
String s1=request.getParameter("studid");
int studId=Integer.parseInt(s1);

try {
Class.forName("oracle.jdbc.driver.OracleDriver");
Connection cname=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "system");
PreparedStatement ps=cname.prepareStatement("select * from student1 where stu_id=?");
ps.setInt(1,studId );

ResultSet rs=ps.executeQuery();
if(rs.next())
{
	StudentVO sv=new StudentVO();
	sv.setStudentId(rs.getInt(2));
	sv.setMobile(rs.getLong(5));
	System.out.println(rs.getLong(5));
	sv.setDob(rs.getDate(7));
	sv.setStudentAddress(rs.getString(4));
	sv.setStudentEmail(rs.getString(6));
	sv.setStudentMarks(rs.getInt(3));
	sv.setStudentName(rs.getString(1));
//cname.commit();

//PrintWriter out=response.getWriter();
//
	request.setAttribute("svkey", sv);
	RequestDispatcher rd=request.getRequestDispatcher("NewDisplay.jsp");
	rd.forward(request, response);
}
else
response.sendRedirect("SelectStudent.html");
}
catch(ClassNotFoundException c)
{
System.out.println(c);
}
catch(SQLException s)
{
System.out.println(s);
}
}

}
