import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Formatter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import School.ShowVO;

/**
 * Servlet implementation class Show
 */
@WebServlet("/Show")
public class Show extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try
		{
			String name=request.getParameter("cname");
	    	String add=request.getParameter("cadd");
	    	String state=request.getParameter("cstate");
	    	int phone=Integer.parseInt(request.getParameter("cphone"));
	    	System.out.println(phone);
	    	String email=request.getParameter("cemail");
	    	String type=request.getParameter("ctype");
	    	Date dt= new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("cdate"));
	    	java.sql.Date d= new java.sql.Date(dt.getTime());
	    	String des=request.getParameter("cdes");
	   /*
	    if(request.getParameter("submit").equals("Preview"))
	    {
		ShowVO so=new ShowVO();
		so.setName(name);
		so.setAddress(add);
		so.setState(state);
		so.setPhone(phone);
	    so.setEmail(email);
	    so.setType(type);
	    so.setDov(new SimpleDateFormat("yyyy-MM-dd").format(dt));
	    so.setDisp(des);
	    
	    request.setAttribute("s",so);
		RequestDispatcher rd=request.getRequestDispatcher("Preview.jsp");
		rd.forward(request, response);
	    } 
	    else
	    {*/
	    	PrintWriter out= response.getWriter();
	    	Class.forName("oracle.jdbc.driver.OracleDriver");
	    	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
	    	PreparedStatement ps= con.prepareStatement("INSERT INTO consumer_details VALUES(?,?,?,?,?,?,?,?)");
	    	ps.setString(1,name);
	    	ps.setString(2,add);
	    	ps.setString(3,state);
	    	ps.setLong(4,phone);
	    	ps.setString(5,email);
	    	ps.setString(6,type);
	    	ps.setDate(7,d);
	    	ps.setString(8,des);
	    	
	    	int res=ps.executeUpdate();
	    	if(res>0)
	    	{
	    	con.commit();
	    	out.println(" Registered Successfully...");
	    	}
}
	    
		catch(ParseException e)
		{
			System.out.println(e);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}

