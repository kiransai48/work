

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Add extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name = request.getParameter("sname");
		String add = request.getParameter("add");
		String st = request.getParameter("state");
		String mobno = request.getParameter("mobile");
		String em = request.getParameter("email");
		String dv = request.getParameter("dob");
		String cont = request.getParameter("contact");
		String inti = request.getParameter("incident");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
			SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
			java.util.Date dj = sdf.parse(dv);
			java.sql.Date ds = new java.sql.Date(dj.getTime());
			PreparedStatement ps = con.prepareStatement("INSERT INTO form VALUES(?,?,?,?,?,?,?,?)");
			ps.setString(1,name );
			ps.setString(2, add);
			ps.setString(3, st);
			ps.setString(4,mobno );
			ps.setString(5, em);
			ps.setDate(7, ds);
			ps.setString(6, cont);
			ps.setString(8,inti );
			int rs = ps.executeUpdate();
			if(rs>0){
				PrintWriter out = response.getWriter();
				out.println("Registration successfull");
				con.commit();
			}
		} catch (ClassNotFoundException e) {
			
			System.out.println(e);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		
		
	}

}